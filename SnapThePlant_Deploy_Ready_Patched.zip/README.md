# SnapThePlant

Deploy-ready build for Netlify + Porkbun.

Instructions included inside.