SnapThePlant Pro Pack

What's Inside:
- Offline version of the SnapThePlant app (HTML)
- Safe Plants PDF
- Basic care checklist

Instructions:
Open 'index.html' in your browser to use the offline app.
